#ifndef test_hpp
#define test_hpp

int cxxFunction(int n);

#endif