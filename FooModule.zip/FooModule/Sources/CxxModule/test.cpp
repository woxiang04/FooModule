#include "test.hpp"

int cxxFunction(int n) {
    return n;
}