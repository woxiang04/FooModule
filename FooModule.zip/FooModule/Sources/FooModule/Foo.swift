// Foo.swift

import CxxModule
// import Foundation

func startLoad() {
    print("startLoad")
    print("call cxxFunction:\(cxxFunction(123))")
}
